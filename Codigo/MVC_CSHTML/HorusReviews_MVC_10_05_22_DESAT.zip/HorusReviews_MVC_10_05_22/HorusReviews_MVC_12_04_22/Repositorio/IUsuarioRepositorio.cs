﻿using HorusReviews_MVC_12_04_22.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HorusReviews_MVC_12_04_22.Repositorio
{
    public interface IUsuarioRepositorio
    {

        UsuarioModel Cadastro (UsuarioModel cadastro);

    }
}
