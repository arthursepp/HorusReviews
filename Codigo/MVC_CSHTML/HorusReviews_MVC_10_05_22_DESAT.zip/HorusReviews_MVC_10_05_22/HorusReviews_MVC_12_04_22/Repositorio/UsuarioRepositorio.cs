﻿using HorusReviews_MVC_12_04_22.Data;
using HorusReviews_MVC_12_04_22.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HorusReviews_MVC_12_04_22.Repositorio
{
    public class UsuarioRepositorio : IUsuarioRepositorio
    {
        private readonly BancoContext _bancoContext;
        public UsuarioRepositorio(BancoContext bancoContext)
        {
            _bancoContext = bancoContext;
        }

        public UsuarioModel Cadastro(UsuarioModel cadastro)
        {
            _bancoContext.Usuario.Add(cadastro);
            _bancoContext.SaveChanges();
            return cadastro;
            //Gravar no banco de dados
        }
    }
}
