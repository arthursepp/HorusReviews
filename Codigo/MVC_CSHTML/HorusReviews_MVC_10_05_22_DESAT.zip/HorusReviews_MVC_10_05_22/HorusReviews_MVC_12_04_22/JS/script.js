﻿function msgConfirm() {

    alert("Usuário cadastrado!");

}