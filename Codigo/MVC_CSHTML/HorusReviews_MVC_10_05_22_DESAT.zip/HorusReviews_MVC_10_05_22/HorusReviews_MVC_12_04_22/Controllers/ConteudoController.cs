﻿using Microsoft.AspNetCore.Mvc;

namespace HorusReviews_MVC_12_04_22.Controllers
{
    public class ConteudoController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Filme()
        {
            return View();
        }

    }
}
