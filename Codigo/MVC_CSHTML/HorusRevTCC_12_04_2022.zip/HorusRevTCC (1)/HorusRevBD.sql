
USE HorusRev

CREATE TABLE Usur(

	CodUser		INT			NOT NULL IDENTITY (1,1),
	UserName	VARCHAR(15) NOT NULL,
	CONSTRAINT	PK_UserName PRIMARY KEY(UserName),
	Nome		VARCHAR(50)	NOT NULL,
	DataNasc	DATE		NOT NULL,
	Email		VARCHAR(55) NOT NULL,
	Senha		VARCHAR(12) NOT NULL

)


CREATE TABLE Conteudo(

	ContCod		INT			NOT NULL IDENTITY(1,1),
	CONSTRAINT	PK_ContCod	PRIMARY KEY(ContCod),
	ContName	VARCHAR		NOT NULL

)


CREATE TABLE Coment(

	UserNameComent		VARCHAR(15) NOT NULL,
	CONSTRAINT			FK_UserName FOREIGN KEY(UserNameComent) REFERENCES Usur(UserName),
	CodComent			INT			NOT NULL,
	CONSTRAINT			PK_CodComent	PRIMARY KEY(CodComent),
	DataPost			DATE		NOT NULL

)

SELECT * FROM Usur

DROP TABLE Usur
DROP TABLE Coment
DROP TABLE Conteudo
