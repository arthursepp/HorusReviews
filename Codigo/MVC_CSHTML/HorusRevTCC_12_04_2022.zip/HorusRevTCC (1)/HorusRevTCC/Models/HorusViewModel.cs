﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HorusRevTCC.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HorusRevTCC.Models
{
    public class HorusViewModel
    {
        public int CodUser { get; set; }
        public string UserName { get; set; }
        public string Nome { get; set; }
        public System.DateTime DataNasc { get; set; }
        public string Email { get; set; }
        public string Senha { get; set; }

    }
}