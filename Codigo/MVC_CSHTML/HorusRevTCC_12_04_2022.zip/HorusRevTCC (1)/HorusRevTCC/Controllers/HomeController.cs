﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HorusRevTCC.Models;

namespace HorusRevTCC.Controllers
{
    public class HomeController : Controller
    {
        private HorusRevEntities db = new HorusRevEntities();// cópia do BD// GET: Home
        public ActionResult Index()
        {
            ViewBag.filmes = new[]
            {
                new SelectListItem() {Value="fil", Text = "Filmes"},
                new SelectListItem() {Value="ser", Text = "Séries"},
                new SelectListItem() {Value="ani", Text = "Animes"},
                new SelectListItem() {Value="hqs", Text = "HQs"},
                new SelectListItem() {Value="perfil"}

            };
            return View();
        }

        public ActionResult Login()// carrega a view login
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(string UserName, string Nome, DateTime DataNasc, string Email, string Senha, Usur usur)
        {
            if (ModelState.IsValid)
            {
                db.Usur.Add(usur);
                db.SaveChanges();
                ViewBag.msg = "<script>alert('Dados salvos');</script>";

            }
            
            return View();
        }
        public ActionResult Perfil()// carrega a view login
        {
            return View();
        }
    }
}
