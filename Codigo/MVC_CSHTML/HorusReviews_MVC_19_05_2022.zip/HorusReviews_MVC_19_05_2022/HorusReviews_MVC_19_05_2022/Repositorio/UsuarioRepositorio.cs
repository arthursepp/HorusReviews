﻿using HorusReviews_MVC_19_05_2022.Data;
using HorusReviews_MVC_19_05_2022.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HorusReviews_MVC_19_05_2022.Repositorio
{
    public class UsuarioRepositorio : IUsuarioRepositorio
    {
        private readonly BancoContext _bancoContext;
        public UsuarioRepositorio(BancoContext bancoContext)
        {
            _bancoContext = bancoContext;
        }

        public UsuarioModel Cadastrar(UsuarioModel cadastro)
        {
            _bancoContext.Usuario.Add(cadastro);
            _bancoContext.SaveChanges();
            return cadastro;
        }
    }
}
