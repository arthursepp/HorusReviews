﻿using HorusReviews_MVC_19_05_2022.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HorusReviews_MVC_19_05_2022.Repositorio
{
    public interface IUsuarioRepositorio
    {
        UsuarioModel Cadastrar(UsuarioModel cadastro);
    }
}
