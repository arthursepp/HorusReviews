﻿using Microsoft.AspNetCore.Mvc;

namespace HorusReviews_MVC_19_05_2022.Controllers
{
    public class PerfilController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Perfil()
        {
            return View();
        }
    }
}
