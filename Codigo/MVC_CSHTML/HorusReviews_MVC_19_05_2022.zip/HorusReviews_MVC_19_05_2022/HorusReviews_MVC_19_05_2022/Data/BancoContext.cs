﻿using HorusReviews_MVC_19_05_2022.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HorusReviews_MVC_19_05_2022.Data
{
    public class BancoContext : DbContext
    {
        public BancoContext(DbContextOptions<BancoContext> options) : base(options)
        {
        }
        public DbSet<UsuarioModel> Usuario { get; set; }
        public DbSet<ComentarioModel> Comentario { get; set; }
        public DbSet<ConteudoModel> Conteudo { get; set; }
    }
}
