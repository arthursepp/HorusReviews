﻿using Microsoft.AspNetCore.Mvc;

namespace HorusReviews_MVC_19_05_2022.Controllers
{
    public class CadastroController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Cadastro()
        {
            return View();
        }
    }
}
