package com.example.horusreviews_kotlin_drawer.view

import android.view.View
import android.view.ViewGroup
import android.view.ViewParent
import androidx.recyclerview.widget.RecyclerView
import com.example.horusreviews_kotlin_drawer.domain.NavMenuItem

class NavMenuItemsAdapter ( val items: List<NavMenuItem> ):
    RecyclerView.Adapter<NavMenuItemsAdapter.ViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        type: Int): ViewHolder {
        TODO("Not yet implemented")
    }
    override fun onBindViewHolder(
        holder: ViewHolder,
        position: Int) {
        TODO("Not yet implemented")
    }

    override fun getItemCount()= items.size

        inner class ViewHolder( itemView: View): RecyclerView.ViewHolder( itemView ) {

        }

}