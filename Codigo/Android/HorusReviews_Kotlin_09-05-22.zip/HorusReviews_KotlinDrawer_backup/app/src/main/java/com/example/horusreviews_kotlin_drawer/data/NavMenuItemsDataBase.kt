package com.example.horusreviews_kotlin_drawer.data

import android.content.Context
import com.example.horusreviews_kotlin_drawer.R
import com.example.horusreviews_kotlin_drawer.domain.NavMenuItem

class NavMenuItemsDataBase ( context: Context){

    val items = listOf(

        NavMenuItem(

            context.getString(R.string.item_categoria)
        ),
        NavMenuItem(

            context.getString(R.string.item_filme),
            R.drawable.ic_filmstrip_black_24dp
        ),
        NavMenuItem(

            context.getString(R.string.item_serie),
            R.drawable.ic_television_classic_black_24dp
        ),
        NavMenuItem(

            context.getString(R.string.item_anime),
            R.drawable.ic_play_box_outline_black_24dp
        ),

            context.getString(R.string.item_privacy_policy),
            R.drawable.ic_book_account_black_24dp
        )

    val itemsLogged = listOf(

        NavMenuItem(

            context.getString(R.string.item_perfil),
            R.drawable.ic_account_black_24dp
        ),
        NavMenuItem(

            context.getString(R.string.item_settings),
            R.drawable.ic_cog_play_black_24dp
        ),
        NavMenuItem(

            context.getString(R.string.item_sign_out),
            R.drawable.ic_location_exit_black_24dp
        )
    )

}