﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HorusReviews_MVC_12_04_22.Data
{
    public class BancoContext
    {



    }
}
