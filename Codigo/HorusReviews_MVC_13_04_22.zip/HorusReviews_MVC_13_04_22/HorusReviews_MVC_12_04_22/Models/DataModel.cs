﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HorusReviews_MVC_12_04_22.Models
{
    public class DataModel
    {

        public int CodUser { get; set; }
        public string UserName { get; set; }
        public string Nome { get; set; }
        public System.DateTime DataNasc { get; set; }
        public string Email { get; set; }
        public string Senha { get; set; }
    }
}
